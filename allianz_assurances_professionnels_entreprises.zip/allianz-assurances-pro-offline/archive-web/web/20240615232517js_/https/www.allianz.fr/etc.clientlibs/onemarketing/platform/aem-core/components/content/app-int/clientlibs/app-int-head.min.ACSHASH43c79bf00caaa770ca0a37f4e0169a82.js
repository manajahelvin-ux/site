var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
(function(f,e){window.om=window.om||{};window.om.core=window.om.core||{};window.om.core.paramconfiguration=window.om.core.paramconfiguration||{};window.om.core.paramconfiguration.settings=window.om.core.paramconfiguration.settings||{};window.om.core.paramconfiguration.obj=new function(){this.debug=!1;this.cookiePath="/";this.cookiePrefix="om-param-";this.allowedParams=[];this.start=function(){this.debug&&console.log("init()");this.parseAllowedParams();"undefined"!==typeof om.core.paramconfiguration.settings.cookiePrefix&&
om.core.paramconfiguration.settings.cookiePrefix&&(this.cookiePrefix=om.core.paramconfiguration.settings.cookiePrefix);this.hashBangToCookie()&&this.removeHashbang()};this.hashBangToCookie=function(){var a=!1;if("true"!==om.core.paramconfiguration.settings.isHashbangParamToCookie)return a;var b=e(location).attr("hash");if(!b)return a;this.debug&&console.log("hashBangToCookie() - hash\x3d"+b);b=jQuery.deparam.fragment(b);for(var d in b)if(b.hasOwnProperty(d)&&"undefined"!==typeof d&&d){var c=d.trim();
if(this.isAllowedKey(c)){a=this.cookiePrefix+c;c=b[c];c="undefined"!==typeof c?c.trim():"";var g=this.getExpirationDate();a=this.setCookie(a,c,g)}}return a};this.parseAllowedParams=function(){"undefined"!==typeof om.core.paramconfiguration.settings.allowedParams&&om.core.paramconfiguration.settings.allowedParams&&(this.allowedParams=om.core.paramconfiguration.settings.allowedParams.split(","),this.allowedParams=this.allowedParams.map(Function.prototype.call,String.prototype.trim),this.debug&&console.log("parseAllowedParams() - allowedParams\x3d"+
this.allowedParams))};this.isAllowedKey=function(a){return 0===this.allowedParams.length?!0:0<=e.inArray(a,this.allowedParams)};this.setCookie=function(a,b,d){d instanceof Date?Cookies.set(a,b,{expires:d,path:this.cookiePath}):Cookies.set(a,b,{path:this.cookiePath});this.debug&&console.log("hashBangToCookie() - stored cookieName\x3d"+a+", cookieValue\x3d"+b);return!0};this.getExpirationDate=function(){if(om.core.paramconfiguration.settings.expires){var a=parseInt(om.core.paramconfiguration.settings.expires);
if(!isNaN(a)&&0<a){this.debug&&console.log("hashBangToCookie() - expires\x3d"+a);var b=new Date;b.setTime(b.getTime()+864E5*a)}}return b};this.removeHashbang=function(){if("true"===om.core.paramconfiguration.settings.isRemoveHashbang)if(this.debug&&console.log("removeHashbang()"),"undefined"!==typeof history&&"undefined"!==typeof history.replaceState)try{history.replaceState({},f.title,window.location.pathname+window.location.search)}catch(a){window.location.hash=""}else window.location.hash=""}};
window.om.core.paramconfiguration.obj.start()})(document,Granite.$);
}

/*
     FILE ARCHIVED ON 11:28:48 Jun 17, 2024 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 10:12:32 Oct 29, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.449
  load_resource: 2950.369
  PetaboxLoader3.resolve: 1006.846
  PetaboxLoader3.datanode: 1942.821
*/