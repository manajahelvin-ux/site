var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
(function(a,e){var u=a("header"),l=a(".c-header-metabar__agent--find,.c-header-metabar__find-agent"),f=a(".c-header-metabar__agent.c-header-metabar__agent--showpreferred"),m=a(".c-navigation__agent--find-agent-link"),n=a(".c-navigation__agent--tied-agent-link"),v=a("#preferred-salesrep-image-template").html(),w=a("#preferred-salesrep-short-template").html(),x=a("#preferred-salesrep-in-navigation-short-template").html(),y=a("#preferred-salesrep-flyout-template").html(),z=a("#preferred-salesrep-in-navigation-flyout-template").html(),
p=a(".c-navigation__menu-label--find-agent.js-find-agent-link"),q=a(".c-navigation__menu-label--sales-rep.c-navigation__menu-label--find-agent"),g=a(".c-navigation__menu-label--find-agent.c-navigation__find-agent--custom"),A=a(".c-navigation__submenus-wrapper.c-navigation__submenus--find-agent-wrapper"),B=a(".find-agent-2-level-item"),C=a(".tied-agent-2-level"),D=a("#preferred-salesrep-in-nav-short-template-two-level").html(),E=a("#preferred-salesrep-in-nav-flyout-template-two-level").html(),F=decodeURI(f.find("input.preferredAgentUrl").val()),
G=function(){return u.hasClass("preferred-agents--disabled")?!0:!1},r=function(){l.fadeIn(200);p.show();0!==g.length&&A.remove();g.show();m.removeClass("u-hidden-small-down");n.addClass("u-hidden-small-down");C.hide()},t=function(c,h,k){c=F.replace("%agencyId",c).replace("%childAgencyId",h).replace("%agentId",k);a.ajax({url:c,method:"GET"}).done(function(d){if("success"===d.status){d=d.data;var b=a(".c-salesrep__stage").data("agency-id");"undefined"!==typeof b&&(d=a.extend(d,{currentAgencyId:b}));
b=e.template(v);b=b(d);a(".c-tied-agent-metabar__left").html(b);a(".c-header-dropdown__toggle picture.c-header-dropdown__agent-image").remove();0===a(".c-header-metabar__agent .c-header-dropdown__toggle").find("picture.c-header-dropdown__agent-image").length&&0===a(".c-header-metabar__agent .c-header-dropdown__toggle").find(".c-icon--product-person").length&&a(".c-header-metabar__agent .c-header-dropdown__toggle").prepend(b);0===a(".c-navigation__menu-agent .c-navigation__menu-label--find-agent").find("picture.c-header-dropdown__agent-image").length&&
a(".c-navigation__menu-agent .c-navigation__menu-label--find-agent").prepend(b);b=e.template(w);b=b(d);a(".c-tied-agent-metabar__info--full").html(b);a(".c-header-dropdown__agent-label").empty().append(b);b=e.template(x);b=b(d);a(".c-navigation__menu-agent .c-navigation__meta-label-wrapper").html(b);b=e.template(y);b=b(d);a(".c-agent-card").html(b);a(".c-header-dropdown__agent-detail").html(b);a(".c-navigation__menu-agent .c-navigation__agent.js-find-agent-mobile").remove();b=e.template(z);b=b(d);
a(".c-navigation__menu-agent .c-header-agent__detail").html(b);a(".c-navigation__menu-agent .c-header-agent__detail").show();b=e.template(D);b=b(d);a(".tied-agent-2-level .c-header__navigation-item-title").html(b);b=e.template(E);b=b(d);a(".tied-agent-2-level .c-header-agent__detail").html(b);a(".tied-agent-2-level .c-header-agent__detail").show();B.hide();q.show();l.hide();f.fadeIn(200);p.hide();g.hide();q.show();m.addClass("u-hidden-small-down");n.removeClass("u-hidden-small-down")}else f.is(":visible")||
r()}).fail(function(){return!1})};a.fn.setPreferredAgent=function(){var c=Cookies.get("salesrep-agent");c="undefined"===typeof c?null:c;null!==c&&(c=JSON.parse(c),t(c.agencyId.toString(),null==c.childAgencyId?null:c.childAgencyId.toString(),c.agentId.toString()))};a(document).ready(function(){0<f.length&&f.setPreferredAgent();G&&r()});window.setPreferredAgent=function(c,h,k){return t(c,h,k)}})($,_);
}

/*
     FILE ARCHIVED ON 11:29:13 Jun 17, 2024 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 10:12:46 Oct 29, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.539
  load_resource: 127.699
  PetaboxLoader3.resolve: 79.325
  PetaboxLoader3.datanode: 30.522
*/